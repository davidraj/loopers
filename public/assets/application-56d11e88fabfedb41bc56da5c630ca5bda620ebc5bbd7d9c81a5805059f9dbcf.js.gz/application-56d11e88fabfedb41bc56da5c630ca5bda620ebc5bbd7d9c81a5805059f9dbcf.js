// Application JavaScript
console.log("TVMaze Looper Application Loaded");
